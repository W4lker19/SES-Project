export const appData = {
  version: '0.15.1',
}
