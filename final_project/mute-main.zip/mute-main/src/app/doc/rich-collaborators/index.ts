export { RichCollaborator } from './RichCollaborator'
export { RichCollaboratorsService } from './rich-collaborators.service'
