export interface ILogDatabase {
  send(data: object): void
}
