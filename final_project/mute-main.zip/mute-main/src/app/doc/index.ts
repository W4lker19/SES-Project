export * from './doc.component'
export * from './doc.module'
