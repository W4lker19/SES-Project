export enum Streams {
  CURSOR,
}
