export enum EProperties {
  profile,
  profileDisplayName,
  theme,
  openedFolder,
  signingKeyPair,
}
