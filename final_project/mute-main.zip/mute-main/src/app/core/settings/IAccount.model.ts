export interface IAccount {
  provider: string
  login: string
  name: string
  email?: string
  avatar?: string
  deviceID: string
}
