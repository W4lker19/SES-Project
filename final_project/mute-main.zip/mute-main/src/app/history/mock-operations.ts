// import { TextDelete, TextInsert } from 'mute-structs'

export const OPERATIONS = [
  // new TextInsert(0, 'Welcome on this document! '),
  // new TextInsert(26, 'We are testing the history tool of mote. '),
  // new TextInsert(67, 'It is built with angular 1.2 ! \n\n'),
  // new TextDelete(62, 1),
  // new TextInsert(62, 'u'),
  // new TextInsert(67, 'Mute is collaborative text editor. '),
  // new TextDelete(127, 3),
  // new TextInsert(127, '4.0.0'),
]
