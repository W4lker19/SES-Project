export const CONTROLS = {
  PLAY: 0,
  PAUSE: 1,
  FAST_REWIND: 2,
  FAST_FORWARD: 3,
}
