import { IEnvironment } from './IEnvironment.model'
import { defaultEnvironment } from './default'


export const environment: IEnvironment = {
  ...defaultEnvironment
}